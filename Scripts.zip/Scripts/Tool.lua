local OrionLib = loadstring(game:HttpGet(('https://raw.githubusercontent.com/shlexware/Orion/main/source')))()


local Window = OrionLib:MakeWindow({Name = "debug gui", HidePremium = false, SaveConfig = true, ConfigFolder = "BFKL"})


local Tab = Window:MakeTab({ 	
    Name = "Main", 	
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false 
})

Tab:AddButton({
    Name = "AutoWin Maths",
    Callback = function()
        for i,v in pairs(game.Workspace:GetChildren()) do
            if v.Name == "Stuff" and v:FindFirstChild("Click") then
                fireclickdetector(v.Click.ClickDetector)
            end
        end
    end 
})

Tab:AddButton({
    Name = "TP1 (Broken)",
    Callback = function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players.Broken_CaptainDave.Character.Head.CFrame
    end
})

Tab:AddButton({
    Name = "Admin Weapon",
    Callback = function()
        game.Lighting.EquipSkin:FireServer(game.Lighting.Weapons["Admin weapon"])
    end
})

Tab:AddButton({
    Name = "Unlock event place",
    Callback = function()
        game.Players.LocalPlayer.Resets.Value = 999
    end
})

Tab:AddButton({
    Name = "Unlock all titles",
    Callback = function()
        game.Players.LocalPlayer.UserId = game.CreatorId
    end
})

Tab:AddButton({
    Name = "God Mode",
    Callback = function()
        game.Lighting.Attacks:Destroy()
    end
})

Tab:AddButton({
    Name = "Unlock all secrets (Click 6 times for gaster)",
    Callback = function()
        for i, v in pairs(game.Workspace:GetChildren()) do
            if v.Name =="ClickDetector" then
                fireclickdetector(v)
            end
        end
    end
})