_G.Grabfruit = true
local PlayerCFrame = game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame

while wait(.1) do
	if _G.Grabfruit == true then
		for i,v in pairs(game.Workspace:GetChildren()) do
			if string.find(v.Name, "Fruit") then
				PlayerCFrame = v.Handle.CFrame
			end
		end
	end
end