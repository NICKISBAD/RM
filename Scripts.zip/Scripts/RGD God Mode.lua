

for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
        if v.Name ~= "Humanoid" and v.CanTouch == true then
        v.CanTouch = false
    end
end

