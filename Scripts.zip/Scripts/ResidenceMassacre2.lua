local function AutoWin()
    while wait() do
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-12.7404289, 26.897953, -23.4515305, 1, 0, 0, 0, 1, 0, 0, 0, 1)
        
        game.Players.LocalPlayer.Character.LeftLeg.Anchored = true
        game.Players.LocalPlayer.Character.RightLeg.Anchored = true
        game.Players.LocalPlayer.Character.Torso.Anchored = true
        game.Players.LocalPlayer.Character.Head.Anchored = true
        game.Players.LocalPlayer.Character.RightArm.Anchored = true
        game.Players.LocalPlayer.Character.LeftArm.Anchored = true
    end
end

local ESPLib = {}

function ESPLib:CreateESPTag(params)
    local RunService = game:GetService("RunService")
    local player = game.Players.LocalPlayer
    local camera = game:GetService("Workspace").CurrentCamera

    local Text = params.Text
    local Part = params.Part
    local TextSize = params.TextSize
    local TextColor = params.TextColor
    local BoxColor = params.BoxColor

    local esp = Instance.new("BillboardGui")
    esp.Name = "esp"
    esp.Size = UDim2.new(0, 200, 0, 50)
    esp.StudsOffset = Vector3.new(0, 1.5, 0) -- Offset to raise the label slightly
    esp.Adornee = Part
    esp.Parent = Part
    esp.AlwaysOnTop = true

    local esplabelfr = Instance.new("TextLabel")
    esplabelfr.Name = "esplabelfr"
    esplabelfr.Size = UDim2.new(1, 0, 0, 70)
    esplabelfr.BackgroundColor3 = Color3.new(0, 0, 0)
    esplabelfr.TextColor3 = TextColor or Color3.fromRGB(255, 255, 255) -- Use provided color or default white
    esplabelfr.BackgroundTransparency = 1
    esplabelfr.TextStrokeTransparency = 0
    esplabelfr.TextStrokeColor3 = Color3.new(0, 0, 0)
    esplabelfr.TextSize = TextSize
    esplabelfr.TextScaled = false
    esplabelfr.Parent = esp

    local box = Instance.new("BoxHandleAdornment")
    box.Name = "box"
    box.Size = Part.Size + Vector3.new(0.5, 0.5, 0.5)
    box.Adornee = Part
    box.AlwaysOnTop = true
    box.Transparency = 0.6
    box.Color3 = BoxColor or Color3.new(0, 0, 255)
    box.ZIndex = 0
    box.Parent = Part

    local function updateesplabelfr()
        local playerPosition = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
        if playerPosition then
            local distance = (playerPosition.Position - Part.Position).Magnitude
            esplabelfr.Text = string.format(Text .. ": %.2f", distance)

            local headPosition = Part.Position + Vector3.new(0, Part.Size.Y / 2, 0)
            local screenPosition, onScreen = camera:WorldToScreenPoint(headPosition)

            if onScreen or playerPosition.Position.Y > Part.Position.Y then
                esp.Adornee = Part
                esp.Enabled = true
                box.Adornee = Part
                box.Visible = true
            else
                esp.Enabled = false
                box.Visible = false
            end
        else
            esp.Enabled = false
            box.Visible = false
        end
    end

    RunService.RenderStepped:Connect(updateesplabelfr)
end

local function MonsterEsp()
	ESPLib:CreateESPTag({
	    Text = "Monster",
	    Part = game:GetService("Workspace").Mutant.DeathHitbox,
	    TextSize = 20,
	    TextColor = Color3.new(255, 0, 0),
	    BoxColor = Color3.new(255,0,0)
	})
end

local OrionLib = loadstring(game:HttpGet(('https://raw.githubusercontent.com/shlexware/Orion/main/source')))()

local Window = OrionLib:MakeWindow({Name = "Residence Massacre", HidePremium = false, SaveConfig = true, ConfigFolder = "BFKL"})

local Tab = Window:MakeTab({ 	
    Name = "Main", 	
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false 
})

local function button(text, cb)
    Tab:AddButton({
        Name = text,
        Callback = cb
    })
end

button("Auto Win", function()
    AutoWin()
end)

button("Monster Esp", function()
    MonsterEsp()
end)