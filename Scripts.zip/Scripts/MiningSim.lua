local OrionLib = loadstring(game:HttpGet(('https://raw.githubusercontent.com/shlexware/Orion/main/source')))()

local Window = OrionLib:MakeWindow({Name = "Nick's MSim gui", HidePremium = false, SaveConfig = true, ConfigFolder = "MineSim", IntroText = "Mining skid-mulator"})


local Tab = Window:MakeTab({ 	Name = "main", 	Icon = "rbxassetid://4483345998", 	PremiumOnly = false })

local function button(text, callback)
    Tab:AddButton({
	     Name = text,
	     Callback = callback
    })
end

button("To Sell", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game:GetService("Workspace").TeleportPoints.LavaSell.CFrame
end)

_G.Check = 0

button("Set Checkpoint", function()
    _G.Check = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
end)

button("To checkpoint", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = _G.Check
end)