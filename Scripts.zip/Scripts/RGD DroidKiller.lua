while wait() do
    for i,v in pairs(game:GetService("Workspace").Room.Enemies:GetChildren()) do
        if v:IsA"Humanoid" then
            v.MaxHealth = -1
            v.Health = -1
        end
    end
end
