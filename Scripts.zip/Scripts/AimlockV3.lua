local player = game.Players.LocalPlayer
local camera = workspace.CurrentCamera
local Active = false

local function findplr()
    local nearplr, shrtdist, player2 = nil, math.huge, player.Character
    
    for _, plr3 in pairs(game.Players:GetPlayers()) do
        local distance = (player2.HumanoidRootPart.Position - plr3.Character.HumanoidRootPart.Position).Magnitude
            
        if distance < shrtdist then
            nearplr, shrtdist = plr3, distance
        end
    end
    
    return nearplr
end

local function lockon()
    while Active and wait() do
        local target = findplr()
        
        if target then
            local hum = target.Character:FindFirstChild("Humanoid")
            
            if hum and hum.Health > 0 then
                local targpos = hum.Parent.Head.Position
                local campos = camera.CFrame.Position
                local lookvec = (targpos - campos).unit
                local newcampos = targpos - lookvec
                camera.CFrame = CFrame.new(newcampos, targpos)
            else
                wait(0.1)
            end
        end
    end
end

local function toggle()
    Active = not Active
    
    if Active then
        lockon()
    end
end

local gui = Instance.new("ScreenGui")
gui.Name = "LockOnGui"
local button = Instance.new("TextButton")
button.Text = "Toggle Lock-On"
button.Size = UDim2.new(0, 150, 0, 50)
button.Position = UDim2.new(0.5, -75, 0.01, 0)
button.Parent = gui
button.MouseButton1Click:Connect(toggle)
gui.Parent = game.CoreGui
button.BackgroundColor3 = Color3.new(0, 0, 0)
button.TextColor3 = Color3.new(1, 1, 1)
button.BorderSizePixel = 0
button.AutoButtonColor = false
button.Font = Enum.Font.SourceSans
button.TextScaled = true
button.TextStrokeTransparency = 0
button.TextStrokeColor3 = Color3.new(0, 0, 0)
button.TextWrapped = true