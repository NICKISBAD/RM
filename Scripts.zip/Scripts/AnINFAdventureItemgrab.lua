local GC = getconnections or get_signal_cons
if GC then
    for i,v in pairs(GC(game.Players.LocalPlayer.Idled)) do
        if v["Disable"] then
            v["Disable"](v)
        elseif v["Disconnect"] then
            v["Disconnect"](v)
        end
    end
end
game.Players.LocalPlayer.Idled:Connect(function()
        local VU = game.VirtualUser
        VU:CaptureController()
        VU:ClickButton2(Vector2.new())
end)

game.StarterGui:SetCore("SendNotification",{
    Title = "Anti AFK active",
    Text = "Builtin anti afk script activated",
    Duration = 5
})

local OrionLib = loadstring(game:HttpGet(('https://raw.githubusercontent.com/shlexware/Orion/main/source')))()
local Window = OrionLib:MakeWindow({Name = "Nick's AIA gui", HidePremium = false, SaveConfig = true, ConfigFolder = "MineSim", IntroText = "infinite skiddery"})

_G.ItemGrabber = false

local Tab = Window:MakeTab({Name = "Item Spawns", Icon = "rbxassetid://4483345998", PremiumOnly = false })

Tab:AddToggle({
    Name = "Grab all items",
    Default = false,
    Callback = function(value)
        _G.ItemGrabber = value
    end
})

spawn(function()
    while wait() do
        if _G.ItemGrabber then
            for i,v in pairs(game.Workspace:GetChildren()) do
                if v:IsA("Tool") then
                    local handle = v:WaitForChild("Handle") or v:WaitForChild("Handlefruit") or v:WaitForChild("THING") or v:WaitForChild("ask") or v:WaitForChild("Meshes/Sphere") or v:WaitForChild("Bun Bottom") or v:WaitForChild("MeshPart")
                    
                    handle.CFrame = game.Players.LocalPlayer.Character:WaitForChild("HumanoidRootPart").CFrame
                end
            end
        end
    end
end)
