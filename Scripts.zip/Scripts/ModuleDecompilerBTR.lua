local OrionLib = loadstring(game:HttpGet(('https://raw.githubusercontent.com/shlexware/Orion/main/source')))()

_G.Debug = false

if not _G.Debug then
    _G.Window = OrionLib:MakeWindow({Name = "Beat your meat", HidePremium = false, SaveConfig = true, ConfigFolder = "OrionTest"})
elseif _G.Debug then
	_G.Window = OrionLib:MakeWindow({Name = "DebugMode", HidePremium = false, SaveConfig = true, ConfigFolder = "OrionTest"})
end


local Tab = _G.Window:MakeTab({
	Name = "Tab 1",
	Icon = "rbxassetid://4483345998",
	PremiumOnly = false
})

function SimpleDecompile(module)
    local Module = require(module)
    local DecompiledModule = ""
    
    for i, v in pairs(Module) do
        if typeof(v) == "table" then
            for j, z in pairs(v) do
                if typeof(z) == "table" then
                    for c, b in pairs(z) do
                        DecompiledModule = DecompiledModule .. "\n" .. tostring(c) .. " " .. tostring(b)
                    end
                else
                    DecompiledModule = DecompiledModule .. "\n" .. tostring(j) .. " " .. tostring(z)
                end
            end
        else
            DecompiledModule = DecompiledModule .. "\n" .. tostring(i) .. tostring(v)
        end
    end

    return DecompiledModule
end

Tab:AddTextbox({
	Name = "Weapon Gun Module",
	Default = nil,
	Callback = function(v)
		local a = game.ReplicatedStorage.Modules.Tools.Gun.Settings[v]
		local decompiledResult = SimpleDecompile(a)
        print(decompiledResult)
    end
})

Tab:AddTextbox({
	Name = "Weapon melee Module",
	Default = nil,
	Callback = function(v)
		local a = game.ReplicatedStorage.Modules.Tools.Melee.Settings[v]
		local decompiledResult = SimpleDecompile(a)
        print(decompiledResult)
    end
})

Tab:AddTextbox({
	Name = "Weapon Throwable Module",
	Default = nil,
	Callback = function(v)
		local a = game.ReplicatedStorage.Modules.Tools.Throwable.Settings[v]
		local decompiledResult = SimpleDecompile(a)
        print(decompiledResult)
    end
})

Tab:AddTextbox({
	Name = "Armor Module",
	Default = nil,
	Callback = function(v)
		local a = game.ReplicatedStorage.Modules.Tools.Armor.Settings[v]
		local decompiledResult = SimpleDecompile(a)
        print(decompiledResult)
    end
})

Tab:AddButton({
	Name = "Decompile Projectiles",
	Callback = function()
		local a = game.ReplicatedStorage.Modules.Tools.Gun.Projectiles
		local b = SimpleDecompile(a)
		print(b)
		setclipboard(b)
	end
})


for i,v in pairs(game.ReplicatedStorage.Modules.Tools.Gun.Settings:GetChildren()) do
	if v:IsA("ModuleScript") then
		print(v)
	end
end