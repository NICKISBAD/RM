local OrionLib = loadstring(game:HttpGet(('https://raw.githubusercontent.com/shlexware/Orion/main/source')))()

local function NewWindow(params)
	_G.Window = OrionLib:MakeWindow({Name = "Orion Library" or params.Name, HidePremium = false or params.HidePremium, SaveConfig = true, ConfigFolder = nil or params.ConfigFolder, IntroText = "Orion Library" or params.StartupText, IntroIcon = params.IntroIcon or nil, Icon = params.Icon or nil, CloseCallback = params.CallbackCloseFunction or function() print("Window closed") end })
end

local function NewTab(params)
    _G.Tab = _G.Window:MakeTab({
	     Name = params.Name,
	     Icon = "rbxassetid://4483345998",
	     PremiumOnly = params.PremiumOnly
    })
end

local function NewButton(params)
	_G.Tab:AddButton({
		Name = params.Text or "Button Name"
		Callback = params.Function or print("Hello World!")
	})
end

NewWindow({
	Name = "Name Here",
	HidePremium = false,
	ConfigFolder = "StartupConfigFolder"
})

NewTab({
	Name = "Name Here",
	PremiumOnly = false
})