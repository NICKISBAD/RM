local a = game.Workspace:WaitForChild("!Meteorite")

if a then
	game.StarterGui:SetCore("SendNotification",{
		Title = "meteor spawn",
		Text = "go find it dumbass"
	})
end