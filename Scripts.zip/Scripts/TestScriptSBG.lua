local function LoopCBringPlr(Target)
    while wait() do
        game.Players[Target].Character.HumanoidRootPart.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame * CFrame.new(5,0,0)
    end
end

local function LoopCBringNpc(Target)
    while wait() do
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Workspace.Live[Target].HumanoidRootPart.CFrame * CFrame.new(0,0,5)
    end
end

LoopCBringNpc("Weakest Dummy")