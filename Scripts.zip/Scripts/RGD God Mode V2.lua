for i,v in pairs(game.Workspace.Room.Enemies:GetDescendants()) do
    if v:IsA("BasePart") or v:IsA("Part") then
        v.CanTouch = false
    end
end