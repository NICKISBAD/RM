local OrionLib = loadstring(game:HttpGet(('https://raw.githubusercontent.com/shlexware/Orion/main/source')))()


local Window = OrionLib:MakeWindow({Name = "A very intelligent day", HidePremium = false, SaveConfig = true, ConfigFolder = "BFKL"})


local Tab = Window:MakeTab({ 	
    Name = "Main", 	
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false 
})

local function button(text, cb)
    Tab:AddButton({
        Name = text,
        Callback = cb
    })
end

_G.IF = false

Tab:AddToggle({
    Name = "Item farm",
    Default = false,
    Callback = function(v)
        _G.IF = v
    end
})

spawn(function()
    while wait() do
        if _G.IF then
            for i,v in pairs(game.Workspace.SpawnedItems.NaturalSpawned:GetChildren()) do
                if v:IsA("Tool") and v.Name ~= "Arrow" or "Rokakaka Fruit" or "Banknote" or "Requiem Arrow" and "Water" then
                    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.Handle.CFrame
                end
            end
        end
    end
end)