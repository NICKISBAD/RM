local function Msg(Texy)
require(game:GetService("ReplicatedStorage").Notification).new(Texy):Display();
end

Msg("Obtained <Dark Blade>.")