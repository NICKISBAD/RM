local Library = loadstring(game:HttpGet("https://raw.githubusercontent.com/xHeptc/Kavo-UI-Library/main/source.lua"))()
local Window = Library.CreateLib("Cars Trading Autofarm", "DarkTheme")
local Tab = Window:NewTab("Home")
local Section = Tab:NewSection("The Autofarm")

function Teleport(X, Y, Z)
	game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(Vector3.new(X, Y, Z))
end

Section:NewButton("Autofarm Coins", nil, function()
	while wait(0.1) do
        Teleport(147.30520629882812, 16.99782371520996, -642.1301879882812)
        wait(0.2)
        Teleport(-100.12689208984375, 16.99782371520996, -518.02783203125)
        wait(0.2)
        Teleport(-113.33717346191406, 16.99782371520996, -780.0892333984375)
    end
end)