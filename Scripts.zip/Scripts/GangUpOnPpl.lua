local OrionLib = loadstring(game:HttpGet(('https://raw.githubusercontent.com/shlexware/Orion/main/source')))()


local Window = OrionLib:MakeWindow({Name = "debug gui (gang up on ppl)", HidePremium = false, SaveConfig = true, ConfigFolder = "BFKL"})


local Tab = Window:MakeTab({ 	
    Name = "Main", 	
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false 
})

_G.SpawnedMoneyFarm = false
_G.DroppedMoneyFarm = false

Tab:AddToggle({
    Name = "Spawned Money Farm",
    Default = false,
    Callback = function(v)
        _G.SpawnedMoneyFarm = v
        
        spawn(function()
            while wait(0.1) do
                if _G.SpawnedMoneyFarm then
                    game.Players.LocalPlayer.Character:WaitForChild("HumanoidRootPart").CFrame = game:GetService("Workspace").Particles:WaitForChild('Money').Bundle.CFrame
                end
            end
        end)
    end
})



Tab:AddToggle({
    Name = "Dropped Money Farm",
    Default = false,
    Callback = function(v)
        _G.DroppedMoneyFarm = v
        
        spawn(function()
            while wait(0.1) do
                if _G.DroppedMoneyFarm then
                local money = game.Workspace:FindFirstChild("Money")
                if money.WaitTime.Value == 0 then
                    game.Players.LocalPlayer.Character:WaitForChild("HumanoidRootPart").CFrame = money.Part.CFrame
                    end
                end
            end
        end)
    end
})



game:GetService("Workspace").Map.Crusher.Crushee:Destroy()