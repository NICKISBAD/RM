--You must have selected fruit in your bag

function fakepermfruit(fruit,fruit2) 
    
local args = {
 [1] = "LoadFruit",
 [2] = fruit .. "-" .. fruit
}

game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("CommF_"):InvokeServer(unpack(args))

require(game.ReplicatedStorage.Notification).new("You were gifted <".. fruit2.."-"..fruit2.. "> by <rip_indra>!"):Display() 
end

local function FakeLeopardGift()
    
local args = {
 [1] = "LoadFruit",
 [2] = "Leopard-Leopard"
}

   game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("CommF_"):InvokeServer(unpack(args))

require(game.ReplicatedStorage.Notification).new("You were gifted <Leopard-Leopard> by <rip_indra>!"):Display() 
end 


FakeLeopardGift()

fakepermfruit"Dragon", "Dragon