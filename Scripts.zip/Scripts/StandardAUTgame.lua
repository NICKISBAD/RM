local OrionLib = loadstring(game:HttpGet(('https://raw.githubusercontent.com/shlexware/Orion/main/source')))()

local Window = OrionLib:MakeWindow({Name = "Nick's AUT copy gui", HidePremium = false, SaveConfig = true, ConfigFolder = "MineSim", IntroText = "A Universal Skiddery"})


local Tab = Window:MakeTab({ 	Name = "main", 	Icon = "rbxassetid://4483345998", 	PremiumOnly = false })

local function toggle(text, default, callback)
    Tab:AddToggle({
	     Name = text,
	     Default = default,
	     Callback = callback
    })
end

local function button(text, cb)
    Tab:AddButton({
        Name = text,
        Callback = cb
    })
end

local function textbox(text, def, callback)
    Tab:AddTextbox({
        Name = text,
        Default = def,
        TextDisappear = true,
        Callback = callback
    })
end

_G.ItemGrab = false
_G.ItemSell = false
_G.GrabDiary = false

button("Kill DIO", function()
    game:GetService("Workspace")["DIO [BOSS]"].Humanoid.Health = 0
end)

button("Kill DIO", function()
    game:GetService("Workspace")["DIO [BOSS]"].Humanoid.Health = 0
end)

button("Kill Jetstream Sam", function()
    game:GetService("Workspace")["Jetstream Sam [BOSS]"].Humanoid.Health = 0
end)



toggle("Grab all items (ex; holy diary)", false, function(v)
    _G.ItemGrab = v
end)

toggle("AutoSell Holy Diaries and Requiem Arrows", false, function(v)
    _G.ItemSell = v
end)

toggle("Auto Grab all Diaries", false, function(v)
    _G.GrabDiary = v
end)

_G.Plr = nil

textbox("Select Player", "Enter Name", function(v)
    _G.Plr = v
end)

local player = game.Players.LocalPlayer.Character

button("Kill Player", function()
    player.HumanoidRootPart.CFrame = game.Players[_G.Plr].Character.HumanoidRootPart.CFrame
    wait(1)
    
    local args = {
    [1] = game:GetService("Players"):WaitForChild(_G.Plr).Character.Humanoid,
    [2] = game.Players[_G.Plr].Character.Humanoid.MaxHealth,
    [3] = Vector3.new(-19.232891082763672, -0, 5.485977649688721),
    [4] = "rbxassetid://747238556",
    [5] = 0.2,
    [6] = 1,
    [7] = Vector3.new(20, 200, 20),
    [8] = Vector3.new(75, 75, 75),
    [9] = false,
    [10] = Color3.new(1, 0.33333298563957214, 0),
    [11] = Color3.new(1, 0.33333298563957214, 0)
}

game:GetService("ReplicatedStorage"):WaitForChild("newremotes"):WaitForChild("dmgsystem"):WaitForChild("crysdmg"):FireServer(unpack(args))
end)

spawn(function()
    while wait(0.3) do
        if _G.GrabDiary then
            for i,v in pairs(game.Workspace.Items:GetChildren()) do
                if v.Name == "Holy Diary" or "DIO's Diary" then
                    v.Cover.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
                end
            end
        end
    end
end)


spawn(function()
    while wait(0.3) do
        if _G.ItemSell then
            game:GetService("ReplicatedStorage"):WaitForChild("newremotes"):WaitForChild("SellItem"):FireServer("Holy Diary")
        
            game:GetService("ReplicatedStorage"):WaitForChild("newremotes"):WaitForChild("SellItem"):FireServer("Requiem Arrow")
        end
    end
end)


spawn(function()
    while wait(0.3) do
        if _G.ItemGrab then
            for i,v in pairs(game:GetService("Workspace").Items:GetChildren()) do
                if v:IsA("Tool") then
                    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.Handle.CFrame
                end
            end 
        end
    end
end)
