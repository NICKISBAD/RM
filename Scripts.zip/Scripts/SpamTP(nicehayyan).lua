while wait() do
    game.Players.LocalPlayer.Character:WaitForChild("HumanoidRootPart").CFrame = game.Players.nicehayyan.Character.HumanoidRootPart.CFrame * CFrame.new(0, 0, -5)
end