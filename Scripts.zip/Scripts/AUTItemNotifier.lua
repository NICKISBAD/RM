game.Workspace.Items.ChildAdded:Connect(function(item)
    if item:IsA("Tool") then
        local itemName = item.Name
        if itemName ~= "Arrow" and
           itemName ~= "Rokakaka Fruit" and
           itemName ~= "Dank Diary" and
           itemName ~= "DIO's Diary" and
           itemName ~= "Joseph's Gun" and
           itemName ~= "Universe Orb" and
           itemName ~= "Money" and
           itemName ~= "Duality Orb" and
           itemName ~= "Samurai Path" and
           itemName ~= "CrystalGem" and
           itemName ~= "StarGem" then
                game.StarterGui:SetCore("SendNotification", {
                    Title = "Item Spawn",
                    Text = itemName .. " has spawned",
                    Duration = 5
                })
            elseif itemName == "Cosmic Orb" or "Death Note" or "XSoul" then
            game.StarterGui:SetCore("SendNotification", {
                Title = "Really Rare Item!",
                Text = itemName .. " spawned, it doesnt play music go get it",
                Duration = 20
            })
           elseif itemName == "Holy Diary" then
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = item.Cover.CFrame
        end
    end
end)
