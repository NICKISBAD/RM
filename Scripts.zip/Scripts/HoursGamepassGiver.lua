local Library = loadstring(game:HttpGet("https://raw.githubusercontent.com/NICKISBAD/Nick-s-Modded-KAVO-Lib/main/Nick'sModdedKavoLib.lua"))()

local colors = {
    SchemeColor = Color3.fromRGB(100,0,255),
    Background = Color3.fromRGB(0, 0, 0),
    Header = Color3.fromRGB(0, 0, 0),
    TextColor = Color3.fromRGB(255,255,255),
    ElementColor = Color3.fromRGB(20, 20, 20)
}

local Window = Library.CreateLib("Nick's HOURS gamepass giver", colors)

local Tab = Window:NewTab("Main")

local Section = Tab:NewSection("Gamepasses")

Section:NewButton("Hands of Time: HOT", "Gives the HANDS OF TIME gamepass", function()
	repeat wait() getrenv()._G.Premium = true until getrenv()._G.Premium == true
end)

Section:NewButton("Donation", "Click this after you click above button", function()
	repeat wait() getrenv()._G.Cheats = true until getrenv()._G.Cheats == true
	game.Players.LocalPlayer.PlayerGui.AllGui.Menu.CheatRight.Visible = true
	game.Players.LocalPlayer.PlayerGui.AllGui.Menu.CheatLeft.Visible = true
end)
