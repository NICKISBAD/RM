_G.KL = false

local OrionLib = loadstring(game:HttpGet(('https://raw.githubusercontent.com/shlexware/Orion/main/source')))()


local Window = OrionLib:MakeWindow({Name = "Nick's blox fruits gui", HidePremium = false, SaveConfig = true, ConfigFolder = "BFKL"})


local Tab = Window:MakeTab({ 	
    Name = "Main", 	
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false 
})


Tab:AddToggle({
    Name = "Kill Aura",
    Default = false,
    Callback = function(v)
        _G.KL = v
    end
})

spawn(function()
    while wait() do
        if _G.KL then
            for i,v in pairs(game.Workspace.Enemies:GetDescendants()) do
                if v:FindFirstChild("Humanoid") and v:FindFirstChild("HumanoidRootPart") and v.Humanoid.Health > 0 then
                    pcall(function()
                        repeat wait(.1)
                            v.Humanoid.Health = 0
                            v.HumanoidRootPart.CanCollide = false
							sethiddenproperty(game.Players.LocalPlayer, "SimulationRadius", math.huge)
                        until not _G.Kill_Aura  or not v.Parent or v.Humanoid.Health <= 0
                    end)
                end
            end
        end
    end
end)

_G.FA = false

Tab:AddToggle({
    Name = "Fast Attack",
    Default = false,
    Callback = function(v)
        _G.FA = v
    end
})

require(game.ReplicatedStorage.Util.CameraShaker):Stop()

xShadowFastAttackx = require(game:GetService("Players").LocalPlayer.PlayerScripts.CombatFramework)

xShadowx = debug.getupvalues(xShadowFastAttackx)[2]

spawn(function()
    game:GetService("RunService").RenderStepped:Connect(function()
        if _G.FA then
            if typeof(xShadowx) == "table" then
                pcall(function()
                    xShadowx.activeController.timeToNextAttack = (math.huge^math.huge^math.huge)
                    xShadowx.activeController.timeToNextAttack = 0
                    xShadowx.activeController.hitboxMagnitude = 999
                    xShadowx.activeController.active = false
                    xShadowx.activeController.timeToNextBlock = 0
                    xShadowx.activeController.focusStart = 0
                    xShadowx.activeController.increment = 4
                    xShadowx.activeController.blocking = false
                    xShadowx.activeController.attacking = false
                    xShadowx.activeController.humanoid.AutoRotate = 50
                end)
            end
        end
    end)
end)

Tab:AddButton({
    Name = "Buy dough chip",
    Callback = function()
        local args = {
					[1] = "RaidsNpc",
					[2] = "Select",
					[3] = "Dough"
		}
				
		game:GetService("ReplicatedStorage").Remotes.CommF_:InvokeServer(unpack(args))
    end
})

_G.Auto_StartRaid = false

Tab:AddToggle({
    Name = "Auto Start Raid",
    Default = false,
    Callback = function(v)
        _G.Auto_StartRaid = v
    end
})

spawn(function()
    while wait(.1) do
        pcall(function()
            if _G.Auto_StartRaid then
                if game:GetService("Players")["LocalPlayer"].PlayerGui.Main.Timer.Visible == false then
                    if not game:GetService("Workspace")["_WorldOrigin"].Locations:FindFirstChild("Island 1") and game:GetService("Players").LocalPlayer.Backpack:FindFirstChild("Special Microchip") or game:GetService("Players").LocalPlayer.Character:FindFirstChild("Special Microchip") then
                    fireclickdetector(game:GetService("Workspace").Map.CircleIsland.RaidSummon2.Button.Main.ClickDetector)
                end
                end
            end
        end)
    end
end)

_G.AutoBuy = false

Tab:AddToggle({
    Name = "Haki color buyer",
    Default = false,
    Callback = function(v)
        _G.AutoBuy = v
    end
})

spawn(function()
    local args = {
	   [1] = "ColorsDealer",
	   [2] = "2"
    }
    while wait() do
        if _G.AutoBuy then
            game:GetService("ReplicatedStorage").Remotes.CommF_:InvokeServer(unpack(args))
        end
    end
end)