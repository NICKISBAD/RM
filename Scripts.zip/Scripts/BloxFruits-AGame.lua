local function Msg(Texy)
require(game:GetService("ReplicatedStorage").Notification).new(Texy):Display();
end

Msg("Hello!") wait(1) Msg("Would you like to play a game?") wait(4) Msg("Okay! Jump when ready") wait(5) Msg("3..") wait(3) Msg("2..") wait(3) Msg("1..") wait(3) Msg("Here we go!") wait(5) Msg("Uh.. Give it a sec?") wait(5) Msg("There we go, suffer you dumbass") while wait() do game.Players.LocalPlayer.Character.Humanoid.Health =  game.Players.LocalPlayer.Character.Humanoid.Health -100 end